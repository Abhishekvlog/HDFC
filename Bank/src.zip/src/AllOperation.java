public abstract class AllOperation extends Details{
    public abstract void Deposit(int amount);
    public abstract void Withdraw_money(int amount);
    public abstract void Show_balance();
    public abstract void Show_account_details();
}
