public abstract class Details {
    private String name = "Abhishek Kumar";
    private String Account_Number = "102030400";
    private int Bank_Balance = 10000;

    public String getName() {
        return name;
    }

    public String getAccount_Number() {
        return Account_Number;
    }

    public int getBank_Balance() {
        return Bank_Balance;
    }
}
